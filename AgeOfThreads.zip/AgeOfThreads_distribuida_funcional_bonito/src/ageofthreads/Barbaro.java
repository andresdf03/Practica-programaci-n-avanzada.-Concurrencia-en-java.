package ageofthreads;

public class Barbaro {
    private String idBarbaro;

    public Barbaro(String idBarbaro) {
        this.idBarbaro = idBarbaro;
        LoggerSistema.getInstancia().log("Bárbaro " + idBarbaro + " ha sido creado y está listo para ser asignado.");
    }

    public String getIdBarbaro() {
        return idBarbaro;
    }
}
